g++ -O3 main.cpp -o main
